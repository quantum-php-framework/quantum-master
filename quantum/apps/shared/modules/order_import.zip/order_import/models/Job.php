<?php

namespace OrderImport;

class Job extends \Quantum\ActiverecordModel
{
    static $table_name = 'oim_jobs';




}