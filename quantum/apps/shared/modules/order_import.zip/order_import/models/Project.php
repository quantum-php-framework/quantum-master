<?php

namespace OrderImport;

class Project extends \Quantum\ActiverecordModel
{
    static $table_name = 'oim_projects';




}