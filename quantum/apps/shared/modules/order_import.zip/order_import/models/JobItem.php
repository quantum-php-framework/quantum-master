<?php

namespace OrderImport;

class JobItem extends \Quantum\ActiverecordModel
{
    static $table_name = 'oim_job_items';




}