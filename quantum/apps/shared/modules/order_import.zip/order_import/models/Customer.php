<?php

namespace OrderImport;

class Customer extends \Quantum\ActiverecordModel
{
    static $table_name = 'oim_customers';




}