<?php

namespace OrderImport;

class ContactGroup extends \Quantum\ActiverecordModel
{
    static $table_name = 'oim_contact_groups';




}