<?php


namespace OrderImport;


class OrderImporter
{

    public function __construct()
    {

    }

}